2024201085
Assignment 1

Q1:
Used grep to first get all lines with "POST" and then grep again on the result to get lines with 404.

Q2:
Used awk - split on ',' using -F and get values of column 4 and then store the values on a variable and print it.
 
